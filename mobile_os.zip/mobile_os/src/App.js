
// import './App.css';
import { Display } from './Components/Display';

function App() {
  return (
    <div className="App">
     <Display/>
    </div>
  );
}

export default App;
